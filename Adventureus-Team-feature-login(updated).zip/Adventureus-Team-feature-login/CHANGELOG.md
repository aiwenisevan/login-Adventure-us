# CHANGE LOG

This is a file to keep track of all the changes in this project.
Each developers are required to record their changes.

2020-02-23 23:27:58 -8:00 Yuxiang

- Fix the bug on Android App: Cannot load and show event from firestore.
  - **Bug reason**: All google API are Asynchronous API, so If don't wait for task to finish, the variables will be returned without any update.
