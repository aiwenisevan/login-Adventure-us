<?php
    /**
     * Your Twitter App Info
     */
    
    // Consumer Key
    define('CONSUMER_KEY', 'DWPEFvniRpu3bpj5mM3M2ZnvO');  // CONSUMER_KEY_HERE
    define('CONSUMER_SECRET', 'zKh8DVRU2BuFhkt95VtyS04uFAr2w8MqcqtZGkKMoK1iQ9PlAd'); // CONSUMER_SECRET_HERE

    // User Access Token
    define('ACCESS_TOKEN', '2777997085-8tn8nTntaEfTRBIsZ0V22I76AUIkYqVFuUnv3Bw'); // ACCESS_TOKEN_HERE
    define('ACCESS_SECRET', 'AZtonLazfNixH76Bma0lAJbnvrROiBfxjfsVFxFkHF1jR'); // ACCESS_SECRET_HERE