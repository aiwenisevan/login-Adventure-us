package com.adventureus.adventureus.models.callbacks;

import com.adventureus.adventureus.models.types.Post;

import java.util.List;

public interface OnPostCallbackListener {
    /**
     * call when successfully done
     *
     * @param result Returned Posts
     */
    void onSuccess(List<Post> result);

    /**
     * Call when failed to do;
     */
    void onFailed();
}
