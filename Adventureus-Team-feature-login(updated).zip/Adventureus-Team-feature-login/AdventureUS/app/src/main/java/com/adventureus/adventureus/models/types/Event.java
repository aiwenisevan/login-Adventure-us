package com.adventureus.adventureus.models.types;

import com.google.firebase.Timestamp;
import com.google.firebase.firestore.DocumentId;
import com.google.firebase.firestore.GeoPoint;

import java.util.ArrayList;
import java.util.UUID;

public class Event {
    // firestore part
    @DocumentId
    private String id;

    private String title;
    private String description;
    private GeoPoint location;
    private Timestamp createTime;
    private Timestamp lastUpdateTime;
    private Timestamp startTime;
    private Timestamp endTime;
    private ArrayList<String> tags;
    private String catalog;
    private ArrayList<String> organizerIdArray;
    private ArrayList<String> participantIdArray;

    // variables for geoJson
//    boolean favourite ;
//    boolean loading ;
//    float zoom  ;
//    int loading_progress ;
//    String poi;
//    String style;
//    boolean selected ;
//    int bearing  ;
//    int tilt;
    public Event() {
    }

    public Event(String title, String description, GeoPoint location, Timestamp startTime, Timestamp endTime, String catalog, ArrayList<String> organizerIdArray) {
        this.title = title;
        this.description = description;
        this.location = location;
        this.startTime = startTime;
        this.endTime = endTime;
        this.catalog = catalog;
        this.organizerIdArray = organizerIdArray;
        this.id = UUID.randomUUID().toString();
        this.createTime = Timestamp.now();
        this.lastUpdateTime = Timestamp.now();
        this.tags = new ArrayList<String>();
        this.participantIdArray = new ArrayList<String>();
    }

    public Event(String title, String description, GeoPoint location, Timestamp startTime, Timestamp endTime, String catalog, String singleOrganizerId) {
        this(title, description, location, startTime, endTime, catalog, new ArrayList<String>());
        this.organizerIdArray.add(singleOrganizerId);
    }

    public Event(String title, String description, GeoPoint location, Timestamp startTime, Timestamp endTime, String singleOrganizerId) {
        this(title, description, location, startTime, endTime, "", singleOrganizerId);
    }

    public String getId() {
        return id;
    }

    public String getTitle() {
        return title;
    }

    public String getDescription() {
        return description;
    }

    public GeoPoint getLocation() {
        return location;
    }

    public Timestamp getCreateTime() {
        return createTime;
    }

    public Timestamp getLastUpdateTime() {
        return lastUpdateTime;
    }

    public Timestamp getStartTime() {
        return startTime;
    }

    public Timestamp getEndTime() {
        return endTime;
    }

    public ArrayList<String> getTags() {
        return tags;
    }

    public String getCatalog() {
        return catalog;
    }

    public ArrayList<String> getOrganizerIdArray() {
        return organizerIdArray;
    }

    public ArrayList<String> getParticipantIdArray() {
        return participantIdArray;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public void setLocation(GeoPoint location) {
        this.location = location;
    }

    public void setLastUpdateTime(Timestamp lastUpdateTime) {
        this.lastUpdateTime = lastUpdateTime;
    }

    public void setStartTime(Timestamp startTime) {
        this.startTime = startTime;
    }

    public void setEndTime(Timestamp endTime) {
        this.endTime = endTime;
    }

    public void setTags(ArrayList<String> tags) {
        this.tags = tags;
    }

    public void setCatalog(String catalog) {
        this.catalog = catalog;
    }

    public void setOrganizerIdArray(ArrayList<String> organizerIdArray) {
        this.organizerIdArray = organizerIdArray;
    }

    public void setParticipantIdArray(ArrayList<String> participantIdArray) {
        this.participantIdArray = participantIdArray;
    }
}