package com.adventureus.adventureus.models.types;

import com.google.firebase.Timestamp;
import com.google.firebase.firestore.DocumentId;
import com.google.firebase.firestore.GeoPoint;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.UUID;

public class Post {
    @DocumentId
    private String id;

    private String tile;
    private String description;
    private GeoPoint location;
    private Timestamp createTime;
    private Timestamp lastUpdateTime;
    private Timestamp endTime;
    private ArrayList<String> tags;
    private String creatorId;
    private int dislike;
    private int like;
    // replies map: <userId,reply>
    private HashMap<String,String> replies;

    public Post(String tile, String description, GeoPoint location, Timestamp endTime, ArrayList<String> tags, String creatorId) {
        this.id = UUID.randomUUID().toString();
        this.tile = tile;
        this.description = description;
        this.location = location;
        this.endTime = endTime;
        this.tags = tags;
        this.creatorId = creatorId;
        this.createTime = this.lastUpdateTime = Timestamp.now();
    }


    public Post(String tile, String description, GeoPoint location, Timestamp endTime, String creatorId) {
        this(tile,description,location,endTime,new ArrayList<String>(),creatorId);
    }
    public Post(String tile, GeoPoint location, Timestamp endTime, String creatorId) {
        this(tile,"",location,endTime,new ArrayList<String>(),creatorId);
    }

    public void setTile(String tile) {
        this.tile = tile;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public void setLocation(GeoPoint location) {
        this.location = location;
    }

    public void setLastUpdateTime(Timestamp lastUpdateTime) {
        this.lastUpdateTime = lastUpdateTime;
    }

    public void setEndTime(Timestamp endTime) {
        this.endTime = endTime;
    }

    public void setTags(ArrayList<String> tags) {
        this.tags = tags;
    }

    public void setDislike(int dislike) {
        this.dislike = dislike;
    }

    public void setLike(int like) {
        this.like = like;
    }

    public void setReplies(HashMap<String, String> replies) {
        this.replies = replies;
    }

    public String getId() {
        return id;
    }

    public String getTile() {
        return tile;
    }

    public String getDescription() {
        return description;
    }

    public GeoPoint getLocation() {
        return location;
    }

    public Timestamp getCreateTime() {
        return createTime;
    }

    public Timestamp getLastUpdateTime() {
        return lastUpdateTime;
    }

    public Timestamp getEndTime() {
        return endTime;
    }

    public ArrayList<String> getTags() {
        return tags;
    }

    public String getCreatorId() {
        return creatorId;
    }

    public int getDislike() {
        return dislike;
    }

    public int getLike() {
        return like;
    }

    public HashMap<String, String> getReplies() {
        return replies;
    }
}