package com.adventureus.adventureus.models.callbacks;

import com.adventureus.adventureus.models.types.User;

import java.util.List;

public interface OnUserCallbackListener {
    /**
     * call when successfully done
     *
     * @param result Returned Users
     */
    void onSuccess(List<User> result);

    /**
     * Call when failed to do;
     */
    void onFailed();
}
