package com.adventureus.adventureus;

import android.app.Activity;
import android.icu.text.DateFormat;
import android.icu.text.SimpleDateFormat;
import android.os.Build;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.RequiresApi;

import com.adventureus.adventureus.models.EventModel;
import com.adventureus.adventureus.models.callbacks.OnEventCallbackListener;
import com.adventureus.adventureus.models.types.Event;
import com.google.firebase.Timestamp;

import java.lang.ref.WeakReference;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;


public class AddEventDetail extends Activity {
    private static WeakReference<MainActivity> mainActivityRef;
    Button cancelButton ;
    Button submitButton ;
    EditText titleText ;
    EditText descriptionText;
    EditText locationText ;
    EditText startTimeText ;
    EditText endTimeText ;
    EditText tagsText ;
    EditText catalogText ;
    View.OnClickListener cancelClickListener = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            finish();
        }
    };
    View.OnClickListener submitClickListener = new View.OnClickListener() {
        @RequiresApi(api = Build.VERSION_CODES.N)
        @Override
        public void onClick(View v) {
            Event newEvent = new Event(titleText.getText().toString(),
                    descriptionText.getText().toString(),
                    mainActivityRef.get().getLastKnownLocation(),
                    getTimestampFromEditText(startTimeText),
                    getTimestampFromEditText(endTimeText),
                    catalogText.getText().toString(),
                    new ArrayList<String>(Arrays.asList("TestOrganizerHashID"))
            );
            EventModel.addNewEvent(newEvent, new OnEventCallbackListener() {
                @Override
                public void onSuccess(List<Event> result) {
                    Toast toast = Toast.makeText(getApplicationContext(), "Add Event success", Toast.LENGTH_LONG);
                    toast.show();
                }

                @Override
                public void onFailed() {
                    Toast toast = Toast.makeText(getApplicationContext(), "Add Event failed", Toast.LENGTH_LONG);
                    toast.show();
                }
            });
        }
    };

    public static void updateActivity(MainActivity activity) {
        mainActivityRef = new WeakReference<MainActivity>(activity);
    }

    @Override
    protected void onCreate(Bundle savedInstanceCreate) {
        super.onCreate(savedInstanceCreate);
        setContentView(R.layout.add_event_detail);
        DisplayMetrics dm = new DisplayMetrics();
        getWindowManager().getDefaultDisplay().getMetrics(dm);
        int width = dm.widthPixels;
        int height = dm.heightPixels;
        getWindow().setLayout((int) (width * .8), (int) (height * .8));
         cancelButton = findViewById(R.id.cancel_button);
         submitButton = findViewById(R.id.submit_button);
         titleText = findViewById(R.id.title_text);
         descriptionText = findViewById(R.id.description_text);
         locationText = findViewById(R.id.location_text);
         startTimeText = findViewById(R.id.start_time_text);
         endTimeText = findViewById(R.id.end_time_text);
         tagsText = findViewById(R.id.tags_text);
         catalogText = findViewById(R.id.catalog_text);
        cancelButton.setOnClickListener(cancelClickListener);
        submitButton.setOnClickListener(submitClickListener);
    }

    @RequiresApi(api = Build.VERSION_CODES.N)
    private Timestamp getTimestampFromEditText(EditText editText) {
        String str = editText.getText().toString();
        DateFormat formatter = new SimpleDateFormat("dd/MM/yyyy HH:mm");
        Date date = new Date();
        try {
            date = formatter.parse(str);
        } catch (ParseException e) {
            e.printStackTrace();
        }
        return new Timestamp(date);
    }


}
