package com.adventureus.adventureus;

import android.app.Activity;
import android.os.Bundle;
import android.util.DisplayMetrics;

public class EventDetailPopup extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceCreate) {

        super.onCreate(savedInstanceCreate);

        setContentView(R.layout.add_event_detail);

        DisplayMetrics dm = new DisplayMetrics();
        getWindowManager().getDefaultDisplay().getMetrics(dm);

        int width = dm.widthPixels;
        int height = dm.heightPixels;

        getWindow().setLayout((int) (width * .8), (int) (height * .8));
    }
}
