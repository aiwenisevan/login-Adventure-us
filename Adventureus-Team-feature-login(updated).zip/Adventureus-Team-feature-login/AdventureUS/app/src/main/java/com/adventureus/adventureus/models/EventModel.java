package com.adventureus.adventureus.models;

import androidx.annotation.NonNull;

import com.adventureus.adventureus.db.DBInstance;
import com.adventureus.adventureus.models.callbacks.OnEventCallbackListener;
import com.adventureus.adventureus.models.types.Event;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.QuerySnapshot;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class EventModel {
    private static final String TAG = "EventModel";
    private static final String COLLECTION_NAME = "events";
    private static DBInstance dbInstance = DBInstance.getInstance();

    public static void addNewEvent(final Event event, final OnEventCallbackListener listener) {
        dbInstance.addNewDocument(COLLECTION_NAME, event, new OnSuccessListener<DocumentReference>() {
            @Override
            public void onSuccess(DocumentReference result) {
                listener.onSuccess(null);
            }
        }, new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception e) {
                listener.onFailed();
            }
        });
    }

    public static void deleteEvent(String eventId, final OnEventCallbackListener listener) {
        dbInstance.deleteById(COLLECTION_NAME, eventId, new OnSuccessListener<DocumentReference>() {
            @Override
            public void onSuccess(DocumentReference result) {
                listener.onSuccess(null);
            }
        }, new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception e) {
                listener.onFailed();
            }
        });
    }

    public static void getEventById(String eventId, final OnEventCallbackListener listener) {
        dbInstance.fetchById(COLLECTION_NAME, eventId, new OnCompleteListener<DocumentSnapshot>() {
            @Override
            public void onComplete(@NonNull Task<DocumentSnapshot> task) {
                if (task.isSuccessful()) {
                    Event event = task.getResult().toObject(Event.class);
                    listener.onSuccess(Arrays.asList(event));
                } else {
                    listener.onFailed();
                }
            }
        });
    }

    public static void getAllEvents(final OnEventCallbackListener listener) {
        dbInstance.fetchAll(COLLECTION_NAME, new OnCompleteListener<QuerySnapshot>() {
            @Override
            public void onComplete(@NonNull Task<QuerySnapshot> task) {
                if (task.isSuccessful()) {
                    List<Event> result = new ArrayList<>();
                    for (DocumentSnapshot document : task.getResult()) {
                        result.add(document.toObject(Event.class));
                    }
                    listener.onSuccess(result);
                } else {
                    listener.onFailed();
                }
            }
        });
    }

    public static void updateById(Event event, String eventId, final OnEventCallbackListener listener) {
        dbInstance.updateById(COLLECTION_NAME, eventId, event, new OnSuccessListener<DocumentReference>() {
            @Override
            public void onSuccess(DocumentReference reference) {
                listener.onSuccess(null);
            }
        }, new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception e) {
                listener.onFailed();
            }
        });

    }

    public static void searchByTitle(Event event, String eventId, final OnEventCallbackListener listener) {

    }

}
