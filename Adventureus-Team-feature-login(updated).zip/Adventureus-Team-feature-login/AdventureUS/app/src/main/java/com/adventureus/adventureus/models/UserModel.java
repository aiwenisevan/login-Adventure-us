package com.adventureus.adventureus.models;

import androidx.annotation.NonNull;

import com.adventureus.adventureus.db.DBInstance;
import com.adventureus.adventureus.models.callbacks.OnUserCallbackListener;
import com.adventureus.adventureus.models.types.User;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.QuerySnapshot;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class UserModel {
    private static final String TAG = "UserModel";
    private static final String COLLECTION_NAME = "users";
    private static DBInstance dbInstance = DBInstance.getInstance();

    public static void addNewUser(final User user, final OnUserCallbackListener listener) {
        dbInstance.addNewDocument(COLLECTION_NAME, user, new OnSuccessListener<DocumentReference>() {
            @Override
            public void onSuccess(DocumentReference result) {
                listener.onSuccess(null);
            }
        }, new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception e) {
                listener.onFailed();
            }
        });
    }

    public static void deleteUser(String userId, final OnUserCallbackListener listener) {
        dbInstance.deleteById(COLLECTION_NAME, userId, new OnSuccessListener<DocumentReference>() {
            @Override
            public void onSuccess(DocumentReference result) {
                listener.onSuccess(null);
            }
        }, new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception e) {
                listener.onFailed();
            }
        });
    }

    public static void getUserById(String userId, final OnUserCallbackListener listener) {
        dbInstance.fetchById(COLLECTION_NAME, userId, new OnCompleteListener<DocumentSnapshot>() {
            @Override
            public void onComplete(@NonNull Task<DocumentSnapshot> task) {
                if (task.isSuccessful()) {
                    User user = task.getResult().toObject(User.class);
                    listener.onSuccess(Arrays.asList(user));
                } else {
                    listener.onFailed();
                }
            }
        });
    }

    public static void getAllUsers(final OnUserCallbackListener listener) {
        dbInstance.fetchAll(COLLECTION_NAME, new OnCompleteListener<QuerySnapshot>() {
            @Override
            public void onComplete(@NonNull Task<QuerySnapshot> task) {
                if (task.isSuccessful()) {
                    List<User> result = new ArrayList<>();
                    for (DocumentSnapshot document : task.getResult()) {
                        result.add(document.toObject(User.class));
                    }
                    listener.onSuccess(result);
                } else {
                    listener.onFailed();
                }
            }
        });
    }

    public static void updateById(User user, String userId, final OnUserCallbackListener listener) {
        dbInstance.updateById(COLLECTION_NAME, userId, user, new OnSuccessListener<DocumentReference>() {
            @Override
            public void onSuccess(DocumentReference reference) {
                listener.onSuccess(null);
            }
        }, new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception e) {
                listener.onFailed();
            }
        });

    }

    public static void searchByTitle(User user, String userId, final OnUserCallbackListener listener) {

    }
}
