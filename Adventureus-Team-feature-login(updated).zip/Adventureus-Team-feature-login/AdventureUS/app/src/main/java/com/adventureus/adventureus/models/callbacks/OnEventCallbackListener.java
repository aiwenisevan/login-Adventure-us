package com.adventureus.adventureus.models.callbacks;

import com.adventureus.adventureus.models.types.Event;

import java.util.List;

public interface OnEventCallbackListener {

    /**
     * call when successfully done
     *
     * @param result  Returned Events
     */
    void onSuccess(List<Event> result);

    /**
     * Call when failed to do;
     */
    void onFailed();
}
