package com.adventureus.adventureus.models.types;

import com.google.firebase.Timestamp;
import com.google.firebase.firestore.DocumentId;
import com.google.firebase.firestore.GeoPoint;

import java.util.ArrayList;
import java.util.Date;
import java.util.UUID;

public class User {
    public User(GENDER gender, String firstName, String lastName, String email, String phone) {
        this.gender = gender;
        this.firstName = firstName;
        this.lastName = lastName;
        this.email = email;
        this.phone = phone;
        this.id = UUID.randomUUID().toString();
        this.friends = new ArrayList<String>();
        this.lastLoginLocation = new GeoPoint(0, 0);
        this.currentLocation = new GeoPoint(0, 0);
        this.createTime = Timestamp.now();
        this.lastUpdateTime = Timestamp.now();
        this.lastLoginTime = new Timestamp(0, 0);
        this.followingEvents = new ArrayList<String>();
        this.postsLike = new ArrayList<String>();
        this.dateOfBirth = new Date(0);
    }

    @DocumentId
    private String id;
    private GENDER gender;
    private String firstName;
    private String lastName;
    private String facebookOauthToken;
    private String googleOauthToken;
    private String email;
    private String phone;
    private Timestamp createTime;
    private Timestamp lastUpdateTime;
    private Timestamp lastLoginTime;
    private GeoPoint currentLocation;
    private GeoPoint lastLoginLocation;
    private ArrayList<String> friends;
    private ArrayList<String> followingEvents;
    private ArrayList<String> postsLike;
    private Date dateOfBirth;

    public ArrayList<String> getFollowingEvents() {
        return followingEvents;
    }

    public GENDER getGender() {
        return gender;
    }

    public void setGender(GENDER gender) {
        this.gender = gender;
    }

    public void setFollowingEvents(ArrayList<String> followingEvents) {
        this.followingEvents = followingEvents;
    }

    public ArrayList<String> getPostsLike() {
        return postsLike;
    }

    public void setPostsLike(ArrayList<String> postsLike) {
        this.postsLike = postsLike;
    }

    public Date getDateOfBirth() {
        return dateOfBirth;
    }

    public void setDateOfBirth(Date dateOfBirth) {
        this.dateOfBirth = dateOfBirth;
    }

    public String getId() {
        return id;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getFirstName() {
        return firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public String getFacebookOauthToken() {
        return facebookOauthToken;
    }

    public String getGoogleOauthToken() {
        return googleOauthToken;
    }

    public String getEmail() {
        return email;
    }

    public String getPhone() {
        return phone;
    }

    public Timestamp getCreateTime() {
        return createTime;
    }

    public Timestamp getLastUpdateTime() {
        return lastUpdateTime;
    }

    public Timestamp getLastLoginTime() {
        return lastLoginTime;
    }

    public GeoPoint getCurrentLocation() {
        return currentLocation;
    }

    public GeoPoint getLastLoginLocation() {
        return lastLoginLocation;
    }

    public ArrayList<String> getFriends() {
        return friends;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public void setFacebookOauthToken(String facebookOauthToken) {
        this.facebookOauthToken = facebookOauthToken;
    }

    public void setGoogleOauthToken(String googleOauthToken) {
        this.googleOauthToken = googleOauthToken;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public void setLastUpdateTime(Timestamp lastUpdateTime) {
        this.lastUpdateTime = lastUpdateTime;
    }

    public void setLastLoginTime(Timestamp lastLoginTime) {
        this.lastLoginTime = lastLoginTime;
    }

    public void setCurrentLocation(GeoPoint currentLocation) {
        this.currentLocation = currentLocation;
    }

    public void setLastLoginLocation(GeoPoint lastLoginLocation) {
        this.lastLoginLocation = lastLoginLocation;
    }

    enum GENDER {
        MALE,
        FEMALE,
        UNKNOWN
    }

    public void setFriends(ArrayList<String> friends) {
        this.friends = friends;
    }
}