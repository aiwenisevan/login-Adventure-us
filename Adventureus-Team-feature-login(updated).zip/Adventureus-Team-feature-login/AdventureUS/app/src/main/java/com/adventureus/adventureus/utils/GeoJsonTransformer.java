package com.adventureus.adventureus.utils;

import com.adventureus.adventureus.models.types.Event;
import com.google.gson.Gson;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;


public class GeoJsonTransformer {
    static Gson gson;
    static {
        gson = new Gson();
    }

    public static String eventsToGeoJson(List<Event> events){

        final List<Object> geoFeatures = new ArrayList<>();
        final Map<String, Object> finalGeoJson = new HashMap<>();
        for (Event event : events)
        {
            geoFeatures.add(eventToGeoFeatureMap(event));
        }
        finalGeoJson.put("type", "FeatureCollection");
        finalGeoJson.put("features", geoFeatures);
        return gson.toJson(finalGeoJson);
    }

    private static Map<String, Object> eventToGeoFeatureMap(Event event){
        Map<String, Object> res = new HashMap<>();
        res.put("type", "Feature");

        Map<String, Object> properties = new HashMap<>();
        properties.put("title",event.getTitle());
        properties.put("poi",event.getCatalog());
        properties.put("style", event.getTags().toString());
        properties.put("description",event.getDescription());
        properties.put("call-out",event.getDescription());
        properties.put("selected", false);
        properties.put("loading", false);
        properties.put("loading_progress", 0);
        properties.put("favourite", false);
        properties.put("zoom" , 13.5);
        properties.put("bearing" , 35);
        properties.put("tilt" , 28);


        Map<String, Object> geometry = new HashMap<>();
        geometry.put("type","Point");
        geometry.put("coordinates",new double[]{event.getLocation().getLongitude(), event.getLocation().getLatitude()});

        res.put("properties", properties);
        res.put("geometry", geometry);
        return null;
    }
}
