package com.adventureus.adventureus.db;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.firestore.FirebaseFirestore;

public class DBInstance {

    private static final String TAG = "FirebaseController";
    private static DBInstance instance;
    private FirebaseFirestore db_instance;

    private DBInstance() {
        db_instance = FirebaseFirestore.getInstance();
    }

    /**
     * @return the instance of firebase database
     */
    public static DBInstance getInstance() {
        if (instance == null) {
            //synchronized block to remove overhead
            synchronized (DBInstance.class) {
                if (instance == null) {
                    // if instance is null, initialize
                    instance = new DBInstance();
                }
            }
        }
        return instance;
    }

    /**
     * @param collectionName    collection name
     * @param documentID        document id
     * @param data              new data
     * @param onSuccessListener listener
     * @param onFailureListener listener
     */
    public void updateById(String collectionName, String documentID, Object data, OnSuccessListener onSuccessListener, OnFailureListener onFailureListener) {
        db_instance.collection(collectionName).document(documentID)
                .set(data)
                .addOnSuccessListener(onSuccessListener)
                .addOnFailureListener(onFailureListener);
    }

    /**
     * delete one document by specifying  an id
     *
     * @param collectionName    collection name
     * @param documentId        document id
     * @param onSuccessListener success listener
     * @param onFailureListener failure listener
     */
    public void deleteById(String collectionName, String documentId, OnSuccessListener onSuccessListener, OnFailureListener onFailureListener) {
        db_instance.collection(collectionName).document(documentId)
                .delete()
                .addOnSuccessListener(onSuccessListener)
                .addOnFailureListener(onFailureListener);
    }

    /**
     * @param collectionName     collection name
     * @param documentID         document
     * @param onCompleteListener complete listener to notify whether task is completed successfully.
     */
    public void fetchById(String collectionName, String documentID, OnCompleteListener onCompleteListener) {
        db_instance.collection(collectionName).document(documentID).get().addOnCompleteListener(onCompleteListener);
    }

    /**
     * @param documentName       document name
     * @param onCompleteListener complete listener
     */
    public void fetchAll(String documentName, OnCompleteListener onCompleteListener) {
        db_instance.collection(documentName).get().addOnCompleteListener(onCompleteListener);
    }

    /**
     * Add a new document into collection
     *
     * @param collectionName the name of collection where the new document want to save
     * @param data new document obj
     * @param onSuccessListener callback for success
     * @param onFailureListener callback for failure
     */
    public void addNewDocument(String collectionName, Object data, OnSuccessListener onSuccessListener, OnFailureListener onFailureListener) {
        db_instance.collection(collectionName).add(data)
                .addOnSuccessListener(onSuccessListener)
                .addOnFailureListener(onFailureListener);
    }

}
