package com.adventureus.adventureus;

import android.app.Activity;
import android.os.Bundle;
import android.util.DisplayMetrics;

public class OnCardviewEdit extends AddEventDetail {
    @Override
    protected void onCreate(Bundle savedInstanceCreate) {

        super.onCreate(savedInstanceCreate);



    }
}
