package com.adventureus.adventureus.utils;


import com.google.firebase.firestore.GeoPoint;

public class OurGeocoding {
    public static GeoPoint getLocation(String address){
        //TODO: Use MapBox Geocoding to get GeoPoint from address string
        return  new GeoPoint(0,0);
    }

}
